# Recorded results

These results were extracted from the supplied HTML without rerunning R.

| Metric | Logistic regression | Random forest |
| --- | ---: | ---: |
| Accuracy | 0.8000 | 0.8014 |
| Sensitivity (Recall) | 0.5255 | 0.5174 |
| Specificity | 0.8992 | 0.9041 |
| Precision (Pos Pred Value) | 0.6533 | 0.6610 |
| F1-Score | 0.5825 | 0.5805 |
| ROC-AUC | 0.8404 | 0.8272 |

See `model_comparison.csv`, `console_output.txt` and the numbered output files for recorded details. The full interleaved code/output/figure document is `../analysis/Churn_Analysis_With_Results.md`. The HTML has multiple modelling sections; its final comparison table is shown here. These are separate from the PDF’s reported in-sample results.
