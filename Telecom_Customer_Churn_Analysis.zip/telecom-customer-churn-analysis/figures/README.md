# Figures

All 18 embedded figures extracted losslessly from the original HTML, in document order.

## 1. Initial Exploration: Target Variable (Churn) Distribution

![Initial Exploration: Target Variable (Churn) Distribution](01_initial_exploration_target_variable_churn_distribution.png)

## 2. Initial Exploration: Distribution of Tenure

![Initial Exploration: Distribution of Tenure](02_initial_exploration_distribution_of_tenure.png)

## 3. Initial Exploration: Internet Service Providers

![Initial Exploration: Internet Service Providers](03_initial_exploration_internet_service_providers.png)

## 4. Missing Values Map (Raw Data)

![Missing Values Map (Raw Data)](04_missing_values_map_raw_data.png)

## 5. Density Plot of Total Charges (Cleaned Data)

![Density Plot of Total Charges (Cleaned Data)](05_density_plot_of_total_charges_cleaned_data.png)

## 6. Univariate: Cleaned Churn Distribution

![Univariate: Cleaned Churn Distribution](06_univariate_cleaned_churn_distribution.png)

## 7. Univariate: Contract Type Frequencies

![Univariate: Contract Type Frequencies](07_univariate_contract_type_frequencies.png)

## 8. Bivariate: Churn Rate by Contract Type

![Bivariate: Churn Rate by Contract Type](08_bivariate_churn_rate_by_contract_type.png)

## 9. Bivariate: Monthly Charges vs Churn

![Bivariate: Monthly Charges vs Churn](09_bivariate_monthly_charges_vs_churn.png)

## 10. Multivariate: Tenure vs Monthly Charges colored by Churn

![Multivariate: Tenure vs Monthly Charges colored by Churn](10_multivariate_tenure_vs_monthly_charges_colored_by_churn.png)

## 11. Churn by Partner Status

![Churn by Partner Status](11_churn_by_partner_status.png)

## 12. Churn by Tech Support

![Churn by Tech Support](12_churn_by_tech_support.png)

## 13. Churn by Payment Method

![Churn by Payment Method](13_churn_by_payment_method.png)

## 14. The Lifecycle: Tenure vs Monthly Charges

![The Lifecycle: Tenure vs Monthly Charges](14_the_lifecycle_tenure_vs_monthly_charges.png)

## 15. Figure 15

![Figure 15](15_figure_15.png)

## 16. Higher values indicate a stronger impact on customer churn

![Higher values indicate a stronger impact on customer churn](16_higher_values_indicate_a_stronger_impact_on_customer_churn.png)

## 17. Evaluating Discriminatory Power on Unseen Test Data

![Evaluating Discriminatory Power on Unseen Test Data](17_evaluating_discriminatory_power_on_unseen_test_data.png)

## 18. Model Performance Metrics Comparison

![Model Performance Metrics Comparison](18_model_performance_metrics_comparison.png)
