# Telecom Customer Churn Analysis

Academic business analytics project investigating customer churn through exploratory analysis, statistical modelling and customer retention insights.

**Author:** Bharath Bomatanalli Haranath  
**Programme:** MBA in Business Analytics, University of Aberdeen  
**Tools:** R, RStudio, ggplot2, logistic regression and random forest

## Explore the project

- [Academic report](reports/Telecom_Customer_Churn_Analysis_Report.pdf)
- [Complete analysis with code, results and figures](analysis/Churn_Analysis_With_Results.md)
- [All 18 figures](figures/README.md)
- [Recorded model results](results/README.md)
- [R script in Markdown](scripts/Churn_Analysis_Complete_Script.md)
- [Original rendered HTML](analysis/Churn-Analysis-Complete-Script.html) — download and open in a browser

## Business questions

Which customer characteristics are associated with churn? How do contract, tenure, charges and service choices relate to retention? How well do logistic regression and random forest identify customers who churn?

## Final model comparison recorded in the HTML

| Metric | Logistic regression | Random forest |
| --- | ---: | ---: |
| Accuracy | 80.00% | 80.14% |
| Churn recall | 52.55% | 51.74% |
| Specificity | 89.92% | 90.41% |
| Precision | 65.33% | 66.10% |
| F1 score | 0.5825 | 0.5805 |
| ROC-AUC | 0.8404 | 0.8272 |

The HTML includes an 80/20 training/test split and multiple modelling sections. The figures above are transcribed from its final comparison output. They have not been independently reproduced. Logistic regression has higher recorded ROC-AUC, while random forest has slightly higher accuracy. Churn recall near 52% shows that many churners remain undetected at the chosen classification settings.

**The PDF is a separate academic analysis record.** It reports in-sample logistic regression ROC-AUC of 0.846 and accuracy of 80.49%. Those results must not be treated as the HTML’s test-set comparison. Both original records are included, with their differences retained.

## Folder contents

| Folder | Contents |
| --- | --- |
| `data/raw/` | Supplied Excel dataset |
| `scripts/` | Original extracted R source, portable R source, Markdown source and package installer |
| `analysis/` | Original HTML and Markdown analysis with recorded outputs and figures |
| `reports/` | PDF academic report with student ID removed |
| `figures/` | 18 original PNG figures and a visual index |
| `results/` | Printed outputs, model comparison CSV and results summary |
| `outputs/` | Destination for cleaned data on a future R execution |

## Run locally

From RStudio with this repository root as the working directory:

```r
source("scripts/install_packages.R")
source("scripts/churn_analysis.R")
```

The portable script changes the original input paths to `data/raw/Telco-Customer-Churn.xlsx` and the cleaned-data export to `outputs/`. Its original analytical logic is preserved. The unmodified source is in `scripts/churn_analysis_original.R`. The Markdown source also preserves the original paths.

## Provenance and reproducibility

The dataset and HTML are exact copies of the supplied files. The 18 figures are decoded directly from the HTML’s embedded images. Printed output blocks are retained in their original order, including warnings and package messages. No plots or metrics have been fabricated or regenerated. This environment has no R runtime, so the packaged R script has not been rerun. Package versions are not locked.

The dataset's original redistribution licence has not been verified. No open-source licence has been selected for this repository. The report contains the author's academic acknowledgement of AI assistance; AI also assisted the repository packaging and HTML-to-Markdown conversion.
