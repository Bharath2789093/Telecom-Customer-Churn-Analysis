packages <- c("readxl", "dplyr", "ggplot2", "tidyverse", "visdat", "caret", "gridExtra", "pROC", "randomForest")
missing <- setdiff(packages, rownames(installed.packages()))
if (length(missing)) install.packages(missing, repos = "https://cloud.r-project.org")
