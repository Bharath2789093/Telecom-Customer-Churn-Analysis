# Load required libraries

library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(visdat)  # For visualizing missing data

library(caret)   # For modeling and confusion matrix

# ==========================================
# 1. Import data
# ==========================================
print("--- 1. Importing Data ---")

df <- read_excel("C:/Users/Bharath.Haranath/Downloads/Telco-Customer-Churn.xlsx")

# ==========================================
# 2. Initial descriptive analysis / data exploration
# ==========================================
print("--- 2. Initial Descriptive Analysis ---")

# View the dimensions, column names, and data types
glimpse(df)

# Get basic summary statistics for the raw data
summary(df)

# --- NEW: ggplots for initial data exploration ---
# 2a. Initial Exploration: Churn Distribution
plot_churn_initial <- ggplot(df, aes(x = Churn, fill = Churn)) +
  geom_bar(color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Target Variable (Churn) Distribution", 
       x = "Churn", 
       y = "Count")
print(plot_churn_initial)

# 2b. Initial Exploration: Tenure Distribution (Numeric)
plot_tenure_initial <- ggplot(df, aes(x = tenure)) +
  geom_histogram(bins = 30, fill = "dodgerblue", color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Distribution of Tenure", 
       x = "Tenure (Months)", 
       y = "Frequency")
print(plot_tenure_initial)

# 2c. Initial Exploration: Internet Service Types (Categorical)
plot_internet_initial <- ggplot(df, aes(x = InternetService, fill = InternetService)) +
  geom_bar(color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Internet Service Providers", 
       x = "Internet Service Type", 
       y = "Count")
print(plot_internet_initial)

# ==========================================
# 3. Plot graphs to understand the distribution and missing variables
# ==========================================
print("--- 3. Visualizing Missing Data and Raw Distributions ---")

# Coerce TotalCharges to numeric temporarily just for the missing data plot 
# (since it contains spaces in the raw file making it a character)
df_temp <- df %>% mutate(TotalCharges_num = as.numeric(TotalCharges))

# Plot missing values pattern
plot_missing <- vis_miss(df_temp) + 
  ggtitle("Missing Values Map (Raw Data)")
print(plot_missing)

# ==========================================
# 4. Check data quality
# ==========================================
print("--- 4. Checking Data Quality ---")

# Check for unexpected empty strings or space characters across all columns
empty_spaces <- colSums(df == " " | df == "", na.rm = TRUE)
print("Count of empty strings/spaces per column:")

print(empty_spaces[empty_spaces > 0])

# ==========================================
# 5. Fix variable types
# ==========================================
print("--- 5. Fixing Variable Types ---")

df_fixed <- df %>%
  # Convert TotalCharges to numeric (this turns spaces into NAs)
  mutate(TotalCharges = as.numeric(TotalCharges)) %>%
  # SeniorCitizen is categorical (0/1), not a continuous number
  mutate(SeniorCitizen = as.factor(SeniorCitizen)) %>%
  # Convert all remaining character columns to factors
  mutate_if(is.character, as.factor) %>%
  # Drop customerID as it holds no analytical value
  select(-customerID)

# ==========================================
# 6. Handle missing values
# ==========================================
print("--- 6. Handling Missing Values ---")

# Check how many NAs were created in TotalCharges
print(paste("Missing values in TotalCharges:", sum(is.na(df_fixed$TotalCharges))))

# Since it is a very small number (usually 11 out of 7043) representing new customers with 0 tenure, 
# we will drop these rows to ensure clean modeling.
df_clean <- df_fixed %>% drop_na(TotalCharges)

# ==========================================
# 7. Save cleaned dataset
# ==========================================
print("--- 7. Saving Cleaned Dataset ---")

write.csv(df_clean, "Telco-Customer-Churn-Cleaned.csv", row.names = FALSE)
print("Dataset saved as 'Telco-Customer-Churn-Cleaned.csv'")

# ==========================================
# 8. Plot graphs to present cleaned data with distribution
# ==========================================
print("--- 8. Plotting Cleaned Distributions ---")

# Cleaned distribution for TotalCharges
plot_cleaned_totalcharges <- ggplot(df_clean, aes(x = TotalCharges)) + 
  geom_density(fill = "skyblue", alpha = 0.7) + 
  theme_minimal() + 
  labs(title = "Density Plot of Total Charges (Cleaned Data)", x = "Total Charges")
print(plot_cleaned_totalcharges)

# ==========================================
# 9. Univariate analysis
# ==========================================
print("--- 9. Univariate Analysis ---")

# Target Variable: Churn
plot_uni_churn <- ggplot(df_clean, aes(x = Churn, fill = Churn)) + 
  geom_bar(color = "black") + 
  geom_text(stat='count', aes(label=..count..), vjust=-0.5) +
  theme_minimal() + 
  labs(title = "Univariate: Cleaned Churn Distribution")
print(plot_uni_churn)

# Categorical Feature: Contract types
plot_uni_contract <- ggplot(df_clean, aes(x = Contract)) + 
  geom_bar(fill = "coral", color = "black") + 
  theme_minimal() + 
  labs(title = "Univariate: Contract Type Frequencies")
print(plot_uni_contract)

# ==========================================
# 10. Bivariate analysis
# ==========================================
print("--- 10. Bivariate Analysis ---")

# Churn by Contract Type
plot_biv_contract <- ggplot(df_clean, aes(x = Contract, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() + 
  labs(title = "Bivariate: Churn Rate by Contract Type", y = "Percentage")
print(plot_biv_contract)

# Monthly Charges by Churn
plot_biv_monthly <- ggplot(df_clean, aes(x = Churn, y = MonthlyCharges, fill = Churn)) + 
  geom_boxplot() + 
  theme_minimal() + 
  labs(title = "Bivariate: Monthly Charges vs Churn")
print(plot_biv_monthly)

# ==========================================
# 11. Multivariate analysis
# ==========================================
print("--- 11. Multivariate Analysis ---")

# Interplay of Tenure, Monthly Charges, and Churn
plot_multi <- ggplot(df_clean, aes(x = tenure, y = MonthlyCharges, color = Churn)) + 
  geom_point(alpha = 0.5) + 
  theme_minimal() + 
  labs(title = "Multivariate: Tenure vs Monthly Charges colored by Churn")
print(plot_multi)

# ==========================================
# 12. Churn prediction/model
# ==========================================
print("--- 12. Churn Prediction Model ---")

# Set random seed for reproducibility
set.seed(42)

# Create an 80/20 train-test split
trainIndex <- createDataPartition(df_clean$Churn, p = 0.8, list = FALSE)
train_data <- df_clean[trainIndex, ]
test_data  <- df_clean[-trainIndex, ]

# Build a Logistic Regression Model
logit_model <- glm(Churn ~ tenure + Contract + MonthlyCharges + 
                     InternetService + TechSupport + PaymentMethod + SeniorCitizen,
                   data = train_data, 
                   family = "binomial")

# Output the model summary
print(summary(logit_model))

# Generate predictions on the test set
predicted_probs <- predict(logit_model, test_data, type = "response")

# Convert probabilities to class labels using a 0.5 threshold
predicted_classes <- factor(ifelse(predicted_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# Evaluate the model using a Confusion Matrix
conf_matrix <- confusionMatrix(predicted_classes, test_data$Churn, positive = "Yes")
print(conf_matrix)

#Trying the second approach for the customer Churn analysis.

# ==============================================================================
# SETUP & DATA PREPARATION
# ==============================================================================
# Load necessary libraries
library(readxl)
library(tidyverse)
library(gridExtra) # For arranging multiple plots side-by-side

# Import the data
df <- read_excel("C:/Users/Bharath.Haranath/Downloads/Telco-Customer-Churn.xlsx")

# Clean the data (as established in previous steps)
df_clean <- df %>%
  mutate(TotalCharges = as.numeric(TotalCharges),
         SeniorCitizen = as.factor(SeniorCitizen)) %>%
  mutate_if(is.character, as.factor) %>%
  select(-customerID) %>% # Remove the irrelevant ID column
  drop_na(TotalCharges)   # Drop the 11 rows with missing charges

# Create a custom theme for cleaner charts
my_theme <- theme_minimal() + 
  theme(plot.title = element_text(size = 11, face = "bold"),
        legend.position = "bottom")

# ==============================================================================
# PART 1: DEMOGRAPHICS (Who are they?)
# ==============================================================================
print("--- Analyzing Demographics ---")

# 1. Senior Citizen Status
p1 <- ggplot(df_clean, aes(x = SeniorCitizen, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Senior Citizen Status", y = "% of Customers", x = "Senior Citizen (0=No, 1=Yes)") +
  my_theme

# 2. Partner Status
p2 <- ggplot(df_clean, aes(x = Partner, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Partner Status", y = "", x = "Has Partner") +
  my_theme

# Display Demographic plots together
grid.arrange(p1, p2, ncol = 2)

# ==============================================================================
# PART 2: SERVICES SUBSCRIBED (What are they experiencing?)
# ==============================================================================
print("--- Analyzing Services Subscribed ---")

# 1. Internet Service Type
p3 <- ggplot(df_clean, aes(x = InternetService, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Internet Service", y = "% of Customers", x = "Service Type") +
  my_theme

# 2. Tech Support (Crucial add-on)
p4 <- ggplot(df_clean, aes(x = TechSupport, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Tech Support", y = "", x = "Has Tech Support") +
  my_theme

# Display Service plots together
grid.arrange(p3, p4, ncol = 2)

# ==============================================================================
# PART 3: ACCOUNT & BILLING (How much financial friction is there?)
# ==============================================================================
print("--- Analyzing Account & Billing ---")

# 1. Contract Type
p5 <- ggplot(df_clean, aes(x = Contract, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Contract Type", y = "% of Customers", x = "Contract Length") +
  my_theme

# 2. Payment Method
p6 <- ggplot(df_clean, aes(x = PaymentMethod, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Payment Method", y = "", x = "Method") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position = "none")

# Display Billing plots together
grid.arrange(p5, p6, ncol = 2)

# 3. Continuous Variables: Tenure vs Monthly Charges
ggplot(df_clean, aes(x = tenure, y = MonthlyCharges, color = Churn)) + 
  geom_point(alpha = 0.3) + 
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "The Lifecycle: Tenure vs Monthly Charges", 
       x = "Tenure (Months)", y = "Monthly Charges ($)") +
  my_theme

# ==============================================================================
# PART 4: LOGISTIC REGRESSION (Which category matters most?)
# ==============================================================================
print("--- Modeling the Drivers of Churn ---")

# We build a model using one representative variable from each of our three categories
# Demographics: SeniorCitizen, Partner
# Services: InternetService, TechSupport
# Billing: Contract, MonthlyCharges, tenure

churn_model <- glm(Churn ~ SeniorCitizen + Partner + 
                     InternetService + TechSupport + 
                     Contract + MonthlyCharges + tenure, 
                   data = df_clean, 
                   family = "binomial")

# View the summary to see the p-values and coefficients
# Look for the variables with the most stars (***) - these are your strongest drivers!
summary(churn_model)

# Load pROC for evaluating model performance
library(pROC)
library(caret)

print("--- Evaluating Model Performance ---")

# 1. Split data into Training (80%) and Testing (20%) sets
set.seed(123) # For reproducibility
trainIndex <- createDataPartition(df_clean$Churn, p = .8, list = FALSE)
train_data <- df_clean[trainIndex, ]
test_data <- df_clean[-trainIndex, ]

# 2. Retrain the exact model on just the training data
final_model <- glm(Churn ~ SeniorCitizen + Partner + InternetService + 
                     TechSupport + Contract + MonthlyCharges + tenure, 
                   data = train_data, family = "binomial")

# 3. Predict on the unseen Test Data
predicted_probs <- predict(final_model, test_data, type = "response")
# Convert probabilities > 50% to "Yes"
predicted_classes <- factor(ifelse(predicted_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# 4. Confusion Matrix (Accuracy, Sensitivity, Specificity)
conf_matrix <- confusionMatrix(predicted_classes, test_data$Churn, positive = "Yes")
print(conf_matrix)

# 5. Plot ROC Curve and calculate AUC
roc_curve <- roc(test_data$Churn, predicted_probs)

plot(roc_curve, col = "blue", main = paste("ROC Curve (AUC =", round(auc(roc_curve), 3), ")"))

# ==============================================================================
# PART 5: RANDOM FOREST MODEL (Validating the Findings)
# ==============================================================================
print("--- Building the Random Forest Model ---")

# Install the package if you do not have it: install.packages("randomForest")
library(randomForest)

library(caret)

# Ensure the target variable is a factor (required for classification in Random Forest)
train_data$Churn <- as.factor(train_data$Churn)
test_data$Churn <- as.factor(test_data$Churn)

# 1. Train the Random Forest Model
# We use all predictors (.) to let the algorithm find the most important ones naturally
set.seed(42)
rf_model <- randomForest(Churn ~ ., 
                         data = train_data, 
                         ntree = 500,        # Number of trees to grow
                         importance = TRUE)  # Calculate variable importance

# 2. View the model summary and Out-of-Bag (OOB) error rate
print(rf_model)

# 3. Predict on unseen test data
rf_predictions <- predict(rf_model, test_data)

# 4. Evaluate Performance via Confusion Matrix
rf_conf_matrix <- confusionMatrix(rf_predictions, test_data$Churn, positive = "Yes")
print("--- Random Forest Confusion Matrix ---")

print(rf_conf_matrix)

# ==============================================================================
# PART 6: VARIABLE IMPORTANCE (The Business Insights)
# ==============================================================================
print("--- Extracting Feature Importance ---")

# Extract the importance metrics
importance_data <- as.data.frame(importance(rf_model))
importance_data$Feature <- rownames(importance_data)

# Sort by MeanDecreaseAccuracy (how much accuracy the model loses if this feature is removed)
importance_data <- importance_data[order(-importance_data$MeanDecreaseAccuracy),]

# View the top 10 most important features
print(head(importance_data, 10))

# Plot Variable Importance using ggplot2 for the final report
library(ggplot2)

ggplot(importance_data, aes(x = reorder(Feature, MeanDecreaseAccuracy), y = MeanDecreaseAccuracy)) +
  geom_col(fill = "steelblue", color = "black") +
  coord_flip() + # Flip coordinates for readability
  theme_minimal() +
  labs(title = "Random Forest: Variable Importance for Predicting Churn",
       subtitle = "Higher values indicate a stronger impact on customer churn",
       x = "Dataset Variables",
       y = "Importance (Mean Decrease in Accuracy)") +
  theme(plot.title = element_text(face = "bold"))

# ==============================================================================
# PART 7: MODEL PERFORMANCE COMPARISON (Logistic Regression vs. Random Forest)
# ==============================================================================
library(caret)
library(pROC)
library(ggplot2)
library(tidyverse)

# 1. Generate Class Predictions and Probabilities for Both Models
# --- Logistic Regression ---
lr_probs  <- predict(logit_model, test_data, type = "response")
lr_preds  <- factor(ifelse(lr_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# --- Random Forest ---
rf_preds  <- predict(rf_model, test_data, type = "response")
rf_probs  <- predict(rf_model, test_data, type = "prob")[, "Yes"]

# 2. Compute Confusion Matrices
cm_lr <- confusionMatrix(lr_preds, test_data$Churn, positive = "Yes")
cm_rf <- confusionMatrix(rf_preds, test_data$Churn, positive = "Yes")

# 3. Compute ROC and AUC Scores
roc_lr <- roc(test_data$Churn, lr_probs, levels = c("No", "Yes"))

roc_rf <- roc(test_data$Churn, rf_probs, levels = c("No", "Yes"))

auc_lr <- round(auc(roc_lr), 4)
auc_rf <- round(auc(roc_rf), 4)

# 4. Compile Performance Metrics Summary Table
model_comparison <- data.frame(
  Metric = c("Accuracy", "Sensitivity (Recall)", "Specificity", 
             "Precision (Pos Pred Value)", "F1-Score", "ROC-AUC"),
  
  Logistic_Regression = c(
    round(cm_lr$overall["Accuracy"], 4),
    round(cm_lr$byClass["Sensitivity"], 4),
    round(cm_lr$byClass["Specificity"], 4),
    round(cm_lr$byClass["Pos Pred Value"], 4),
    round(2 * (cm_lr$byClass["Pos Pred Value"] * cm_lr$byClass["Sensitivity"]) / 
            (cm_lr$byClass["Pos Pred Value"] + cm_lr$byClass["Sensitivity"]), 4),
    auc_lr
  ),
  
  Random_Forest = c(
    round(cm_rf$overall["Accuracy"], 4),
    round(cm_rf$byClass["Sensitivity"], 4),
    round(cm_rf$byClass["Specificity"], 4),
    round(cm_rf$byClass["Pos Pred Value"], 4),
    round(2 * (cm_rf$byClass["Pos Pred Value"] * cm_rf$byClass["Sensitivity"]) / 
            (cm_rf$byClass["Pos Pred Value"] + cm_rf$byClass["Sensitivity"]), 4),
    auc_rf
  )
)

print("--- PERFORMANCE COMPARISON TABLE ---")

print(model_comparison)

# ==============================================================================
# VISUALIZATION 1: OVERLAID ROC CURVES
# ==============================================================================
# Convert ROC objects to data frames for ggplot
df_roc_lr <- data.frame(
  Specificity = roc_lr$specificities,
  Sensitivity = roc_lr$sensitivities,
  Model = paste0("Logistic Regression (AUC = ", auc_lr, ")")
)

df_roc_rf <- data.frame(
  Specificity = roc_rf$specificities,
  Sensitivity = roc_rf$sensitivities,
  Model = paste0("Random Forest (AUC = ", auc_rf, ")")
)

df_roc_combined <- rbind(df_roc_lr, df_roc_rf)

ggplot(df_roc_combined, aes(x = 1 - Specificity, y = Sensitivity, color = Model)) +
  geom_line(size = 1.2) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey50") +
  scale_color_manual(values = c("darkblue", "darkgreen")) +
  theme_minimal() +
  labs(
    title = "ROC Curve Comparison: Logistic Regression vs. Random Forest",
    subtitle = "Evaluating Discriminatory Power on Unseen Test Data",
    x = "1 - Specificity (False Positive Rate)",
    y = "Sensitivity (True Positive Rate)",
    color = "Model"
  ) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold", size = 12)
  )

# ==============================================================================
# VISUALIZATION 2: METRIC COMPARISON BAR CHART
# ==============================================================================
df_metrics_long <- model_comparison %>%
  pivot_longer(cols = c("Logistic_Regression", "Random_Forest"), 
               names_to = "Model", values_to = "Value")

ggplot(df_metrics_long, aes(x = Metric, y = Value, fill = Model)) +
  geom_bar(stat = "identity", position = "dodge", color = "black", width = 0.7) +
  geom_text(aes(label = round(Value, 3)), position = position_dodge(0.7), vjust = -0.5, size = 3) +
  scale_y_continuous(limits = c(0, 1.05), labels = scales::percent) +
  scale_fill_manual(values = c("steelblue", "forestgreen")) +
  theme_minimal() +
  labs(
    title = "Model Performance Metrics Comparison",
    x = "Evaluation Metric",
    y = "Score"
  ) +
  theme(
    axis.text.x = element_text(angle = 20, hjust = 1),
    plot.title = element_text(face = "bold")
  )
