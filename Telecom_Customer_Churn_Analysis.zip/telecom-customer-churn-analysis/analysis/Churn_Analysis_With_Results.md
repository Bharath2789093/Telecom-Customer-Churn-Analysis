# Rendered analysis: source, recorded output and figures

Extracted from the supplied HTML. Outputs and figures are existing rendered results, not a new execution. Source code retains the original file paths.

```r
# Load required libraries

library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(visdat)  # For visualizing missing data
```

```text
## Warning: package 'visdat' was built under R version 4.6.1
```

```r
library(caret)   # For modeling and confusion matrix
```

```text
## Warning: package 'caret' was built under R version 4.6.1
```

```text
## Loading required package: lattice
```

```text
## 
## Attaching package: 'caret'
```

```text
## The following object is masked from 'package:purrr':
## 
##     lift
```

```r
# ==========================================
# 1. Import data
# ==========================================
print("--- 1. Importing Data ---")
```

```text
## [1] "--- 1. Importing Data ---"
```

```r
df <- read_excel("C:/Users/Bharath.Haranath/Downloads/Telco-Customer-Churn.xlsx")

# ==========================================
# 2. Initial descriptive analysis / data exploration
# ==========================================
print("--- 2. Initial Descriptive Analysis ---")
```

```text
## [1] "--- 2. Initial Descriptive Analysis ---"
```

```r
# View the dimensions, column names, and data types
glimpse(df)
```

```text
## Rows: 7,043
## Columns: 21
## $ customerID       [3m[38;5;246m<chr>[39m[23m "7590-VHVEG"[38;5;246m, [39m"5575-GNVDE"[38;5;246m, [39m"3668-QPYBK"[38;5;246m, [39m"7795-CFOCW"[38;5;246m, [39m"9237-HQITU"[38;5;246m, [39m"9305-CDSKC"[38;5;246m, [39m"1452-…
## $ gender           [3m[38;5;246m<chr>[39m[23m "Female"[38;5;246m, [39m"Male"[38;5;246m, [39m"Male"[38;5;246m, [39m"Male"[38;5;246m, [39m"Female"[38;5;246m, [39m"Female"[38;5;246m, [39m"Male"[38;5;246m, [39m"Female"[38;5;246m, [39m"Female"[38;5;246m, [39m"Male"[38;5;246m, [39m…
## $ SeniorCitizen    [3m[38;5;246m<dbl>[39m[23m 0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m1[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m0[38;5;246m, [39m…
## $ Partner          [3m[38;5;246m<chr>[39m[23m "Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"N…
## $ Dependents       [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No…
## $ tenure           [3m[38;5;246m<dbl>[39m[23m 1[38;5;246m, [39m34[38;5;246m, [39m2[38;5;246m, [39m45[38;5;246m, [39m2[38;5;246m, [39m8[38;5;246m, [39m22[38;5;246m, [39m10[38;5;246m, [39m28[38;5;246m, [39m62[38;5;246m, [39m13[38;5;246m, [39m16[38;5;246m, [39m58[38;5;246m, [39m49[38;5;246m, [39m25[38;5;246m, [39m69[38;5;246m, [39m52[38;5;246m, [39m71[38;5;246m, [39m10[38;5;246m, [39m21[38;5;246m, [39m1[38;5;246m, [39m12[38;5;246m, [39m1[38;5;246m, [39m58[38;5;246m, [39m…
## $ PhoneService     [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Y…
## $ MultipleLines    [3m[38;5;246m<chr>[39m[23m "No phone service"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No phone service"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No phone service"…
## $ InternetService  [3m[38;5;246m<chr>[39m[23m "DSL"[38;5;246m, [39m"DSL"[38;5;246m, [39m"DSL"[38;5;246m, [39m"DSL"[38;5;246m, [39m"Fiber optic"[38;5;246m, [39m"Fiber optic"[38;5;246m, [39m"Fiber optic"[38;5;246m, [39m"DSL"[38;5;246m, [39m"Fiber opt…
## $ OnlineSecurity   [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No internet servi…
## $ OnlineBackup     [3m[38;5;246m<chr>[39m[23m "Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No internet service…
## $ DeviceProtection [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No internet service…
## $ TechSupport      [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No internet service"[38;5;246m,[39m…
## $ StreamingTV      [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No internet service"…
## $ StreamingMovies  [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No internet service"[38;5;246m,[39m…
## $ Contract         [3m[38;5;246m<chr>[39m[23m "Month-to-month"[38;5;246m, [39m"One year"[38;5;246m, [39m"Month-to-month"[38;5;246m, [39m"One year"[38;5;246m, [39m"Month-to-month"[38;5;246m, [39m"Month-to-mo…
## $ PaperlessBilling [3m[38;5;246m<chr>[39m[23m "Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"…
## $ PaymentMethod    [3m[38;5;246m<chr>[39m[23m "Electronic check"[38;5;246m, [39m"Mailed check"[38;5;246m, [39m"Mailed check"[38;5;246m, [39m"Bank transfer (automatic)"[38;5;246m, [39m"Electron…
## $ MonthlyCharges   [3m[38;5;246m<dbl>[39m[23m 29.85[38;5;246m, [39m56.95[38;5;246m, [39m53.85[38;5;246m, [39m42.30[38;5;246m, [39m70.70[38;5;246m, [39m99.65[38;5;246m, [39m89.10[38;5;246m, [39m29.75[38;5;246m, [39m104.80[38;5;246m, [39m56.15[38;5;246m, [39m49.95[38;5;246m, [39m18.95[38;5;246m, [39m100.3…
## $ TotalCharges     [3m[38;5;246m<dbl>[39m[23m 29.85[38;5;246m, [39m1889.50[38;5;246m, [39m108.15[38;5;246m, [39m1840.75[38;5;246m, [39m151.65[38;5;246m, [39m820.50[38;5;246m, [39m1949.40[38;5;246m, [39m301.90[38;5;246m, [39m3046.05[38;5;246m, [39m3487.95[38;5;246m, [39m587.45…
## $ Churn            [3m[38;5;246m<chr>[39m[23m "No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"No"[38;5;246m, [39m"Yes"[38;5;246m, [39m"…
```

```r
# Get basic summary statistics for the raw data
summary(df)
```

```text
##      customerID         gender     SeniorCitizen         Partner         Dependents       tenure     
##  Length   :7043   Length   :7043   Min.   :0.0000   Length   :7043   Length   :7043   Min.   : 0.00  
##  N.unique :7043   N.unique :   2   1st Qu.:0.0000   N.unique :   2   N.unique :   2   1st Qu.: 9.00  
##  N.blank  :   0   N.blank  :   0   Median :0.0000   N.blank  :   0   N.blank  :   0   Median :29.00  
##  Min.nchar:  10   Min.nchar:   4   Mean   :0.1621   Min.nchar:   2   Min.nchar:   2   Mean   :32.37  
##  Max.nchar:  10   Max.nchar:   6   3rd Qu.:0.0000   Max.nchar:   3   Max.nchar:   3   3rd Qu.:55.00  
##                                    Max.   :1.0000                                     Max.   :72.00  
##                                                                                                      
##     PhoneService    MultipleLines   InternetService   OnlineSecurity    OnlineBackup   DeviceProtection
##  Length   :7043   Length   :7043   Length   :7043   Length   :7043   Length   :7043   Length   :7043   
##  N.unique :   2   N.unique :   3   N.unique :   3   N.unique :   3   N.unique :   3   N.unique :   3   
##  N.blank  :   0   N.blank  :   0   N.blank  :   0   N.blank  :   0   N.blank  :   0   N.blank  :   0   
##  Min.nchar:   2   Min.nchar:   2   Min.nchar:   2   Min.nchar:   2   Min.nchar:   2   Min.nchar:   2   
##  Max.nchar:   3   Max.nchar:  16   Max.nchar:  11   Max.nchar:  19   Max.nchar:  19   Max.nchar:  19   
##                                                                                                        
##                                                                                                        
##     TechSupport      StreamingTV    StreamingMovies      Contract     PaperlessBilling   PaymentMethod 
##  Length   :7043   Length   :7043   Length   :7043   Length   :7043   Length   :7043    Length   :7043  
##  N.unique :   3   N.unique :   3   N.unique :   3   N.unique :   3   N.unique :   2    N.unique :   4  
##  N.blank  :   0   N.blank  :   0   N.blank  :   0   N.blank  :   0   N.blank  :   0    N.blank  :   0  
##  Min.nchar:   2   Min.nchar:   2   Min.nchar:   2   Min.nchar:   8   Min.nchar:   2    Min.nchar:  12  
##  Max.nchar:  19   Max.nchar:  19   Max.nchar:  19   Max.nchar:  14   Max.nchar:   3    Max.nchar:  25  
##                                                                                                        
##                                                                                                        
##  MonthlyCharges    TotalCharges          Churn     
##  Min.   : 18.25   Min.   :  18.8   Length   :7043  
##  1st Qu.: 35.50   1st Qu.: 401.4   N.unique :   2  
##  Median : 70.35   Median :1397.5   N.blank  :   0  
##  Mean   : 64.76   Mean   :2283.3   Min.nchar:   2  
##  3rd Qu.: 89.85   3rd Qu.:3794.7   Max.nchar:   3  
##  Max.   :118.75   Max.   :8684.8                   
##                   NAs    :11
```

```r
# --- NEW: ggplots for initial data exploration ---
# 2a. Initial Exploration: Churn Distribution
plot_churn_initial <- ggplot(df, aes(x = Churn, fill = Churn)) +
  geom_bar(color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Target Variable (Churn) Distribution", 
       x = "Churn", 
       y = "Count")
print(plot_churn_initial)
```

![Initial Exploration: Target Variable (Churn) Distribution](../figures/01_initial_exploration_target_variable_churn_distribution.png)

```r
# 2b. Initial Exploration: Tenure Distribution (Numeric)
plot_tenure_initial <- ggplot(df, aes(x = tenure)) +
  geom_histogram(bins = 30, fill = "dodgerblue", color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Distribution of Tenure", 
       x = "Tenure (Months)", 
       y = "Frequency")
print(plot_tenure_initial)
```

![Initial Exploration: Distribution of Tenure](../figures/02_initial_exploration_distribution_of_tenure.png)

```r
# 2c. Initial Exploration: Internet Service Types (Categorical)
plot_internet_initial <- ggplot(df, aes(x = InternetService, fill = InternetService)) +
  geom_bar(color = "black") +
  theme_minimal() +
  labs(title = "Initial Exploration: Internet Service Providers", 
       x = "Internet Service Type", 
       y = "Count")
print(plot_internet_initial)
```

![Initial Exploration: Internet Service Providers](../figures/03_initial_exploration_internet_service_providers.png)

```r
# ==========================================
# 3. Plot graphs to understand the distribution and missing variables
# ==========================================
print("--- 3. Visualizing Missing Data and Raw Distributions ---")
```

```text
## [1] "--- 3. Visualizing Missing Data and Raw Distributions ---"
```

```r
# Coerce TotalCharges to numeric temporarily just for the missing data plot 
# (since it contains spaces in the raw file making it a character)
df_temp <- df %>% mutate(TotalCharges_num = as.numeric(TotalCharges))

# Plot missing values pattern
plot_missing <- vis_miss(df_temp) + 
  ggtitle("Missing Values Map (Raw Data)")
print(plot_missing)
```

![Missing Values Map (Raw Data)](../figures/04_missing_values_map_raw_data.png)

```r
# ==========================================
# 4. Check data quality
# ==========================================
print("--- 4. Checking Data Quality ---")
```

```text
## [1] "--- 4. Checking Data Quality ---"
```

```r
# Check for unexpected empty strings or space characters across all columns
empty_spaces <- colSums(df == " " | df == "", na.rm = TRUE)
print("Count of empty strings/spaces per column:")
```

```text
## [1] "Count of empty strings/spaces per column:"
```

```r
print(empty_spaces[empty_spaces > 0])
```

```text
## named numeric(0)
```

```r
# ==========================================
# 5. Fix variable types
# ==========================================
print("--- 5. Fixing Variable Types ---")
```

```text
## [1] "--- 5. Fixing Variable Types ---"
```

```r
df_fixed <- df %>%
  # Convert TotalCharges to numeric (this turns spaces into NAs)
  mutate(TotalCharges = as.numeric(TotalCharges)) %>%
  # SeniorCitizen is categorical (0/1), not a continuous number
  mutate(SeniorCitizen = as.factor(SeniorCitizen)) %>%
  # Convert all remaining character columns to factors
  mutate_if(is.character, as.factor) %>%
  # Drop customerID as it holds no analytical value
  select(-customerID)

# ==========================================
# 6. Handle missing values
# ==========================================
print("--- 6. Handling Missing Values ---")
```

```text
## [1] "--- 6. Handling Missing Values ---"
```

```r
# Check how many NAs were created in TotalCharges
print(paste("Missing values in TotalCharges:", sum(is.na(df_fixed$TotalCharges))))
```

```text
## [1] "Missing values in TotalCharges: 11"
```

```r
# Since it is a very small number (usually 11 out of 7043) representing new customers with 0 tenure, 
# we will drop these rows to ensure clean modeling.
df_clean <- df_fixed %>% drop_na(TotalCharges)

# ==========================================
# 7. Save cleaned dataset
# ==========================================
print("--- 7. Saving Cleaned Dataset ---")
```

```text
## [1] "--- 7. Saving Cleaned Dataset ---"
```

```r
write.csv(df_clean, "Telco-Customer-Churn-Cleaned.csv", row.names = FALSE)
print("Dataset saved as 'Telco-Customer-Churn-Cleaned.csv'")
```

```text
## [1] "Dataset saved as 'Telco-Customer-Churn-Cleaned.csv'"
```

```r
# ==========================================
# 8. Plot graphs to present cleaned data with distribution
# ==========================================
print("--- 8. Plotting Cleaned Distributions ---")
```

```text
## [1] "--- 8. Plotting Cleaned Distributions ---"
```

```r
# Cleaned distribution for TotalCharges
plot_cleaned_totalcharges <- ggplot(df_clean, aes(x = TotalCharges)) + 
  geom_density(fill = "skyblue", alpha = 0.7) + 
  theme_minimal() + 
  labs(title = "Density Plot of Total Charges (Cleaned Data)", x = "Total Charges")
print(plot_cleaned_totalcharges)
```

![Density Plot of Total Charges (Cleaned Data)](../figures/05_density_plot_of_total_charges_cleaned_data.png)

```r
# ==========================================
# 9. Univariate analysis
# ==========================================
print("--- 9. Univariate Analysis ---")
```

```text
## [1] "--- 9. Univariate Analysis ---"
```

```r
# Target Variable: Churn
plot_uni_churn <- ggplot(df_clean, aes(x = Churn, fill = Churn)) + 
  geom_bar(color = "black") + 
  geom_text(stat='count', aes(label=..count..), vjust=-0.5) +
  theme_minimal() + 
  labs(title = "Univariate: Cleaned Churn Distribution")
print(plot_uni_churn)
```

![Univariate: Cleaned Churn Distribution](../figures/06_univariate_cleaned_churn_distribution.png)

```r
# Categorical Feature: Contract types
plot_uni_contract <- ggplot(df_clean, aes(x = Contract)) + 
  geom_bar(fill = "coral", color = "black") + 
  theme_minimal() + 
  labs(title = "Univariate: Contract Type Frequencies")
print(plot_uni_contract)
```

![Univariate: Contract Type Frequencies](../figures/07_univariate_contract_type_frequencies.png)

```r
# ==========================================
# 10. Bivariate analysis
# ==========================================
print("--- 10. Bivariate Analysis ---")
```

```text
## [1] "--- 10. Bivariate Analysis ---"
```

```r
# Churn by Contract Type
plot_biv_contract <- ggplot(df_clean, aes(x = Contract, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() + 
  labs(title = "Bivariate: Churn Rate by Contract Type", y = "Percentage")
print(plot_biv_contract)
```

![Bivariate: Churn Rate by Contract Type](../figures/08_bivariate_churn_rate_by_contract_type.png)

```r
# Monthly Charges by Churn
plot_biv_monthly <- ggplot(df_clean, aes(x = Churn, y = MonthlyCharges, fill = Churn)) + 
  geom_boxplot() + 
  theme_minimal() + 
  labs(title = "Bivariate: Monthly Charges vs Churn")
print(plot_biv_monthly)
```

![Bivariate: Monthly Charges vs Churn](../figures/09_bivariate_monthly_charges_vs_churn.png)

```r
# ==========================================
# 11. Multivariate analysis
# ==========================================
print("--- 11. Multivariate Analysis ---")
```

```text
## [1] "--- 11. Multivariate Analysis ---"
```

```r
# Interplay of Tenure, Monthly Charges, and Churn
plot_multi <- ggplot(df_clean, aes(x = tenure, y = MonthlyCharges, color = Churn)) + 
  geom_point(alpha = 0.5) + 
  theme_minimal() + 
  labs(title = "Multivariate: Tenure vs Monthly Charges colored by Churn")
print(plot_multi)
```

![Multivariate: Tenure vs Monthly Charges colored by Churn](../figures/10_multivariate_tenure_vs_monthly_charges_colored_by_churn.png)

```r
# ==========================================
# 12. Churn prediction/model
# ==========================================
print("--- 12. Churn Prediction Model ---")
```

```text
## [1] "--- 12. Churn Prediction Model ---"
```

```r
# Set random seed for reproducibility
set.seed(42)

# Create an 80/20 train-test split
trainIndex <- createDataPartition(df_clean$Churn, p = 0.8, list = FALSE)
train_data <- df_clean[trainIndex, ]
test_data  <- df_clean[-trainIndex, ]

# Build a Logistic Regression Model
logit_model <- glm(Churn ~ tenure + Contract + MonthlyCharges + 
                     InternetService + TechSupport + PaymentMethod + SeniorCitizen,
                   data = train_data, 
                   family = "binomial")

# Output the model summary
print(summary(logit_model))
```

```text
## 
## Call:
## glm(formula = Churn ~ tenure + Contract + MonthlyCharges + InternetService + 
##     TechSupport + PaymentMethod + SeniorCitizen, family = "binomial", 
##     data = train_data)
## 
## Coefficients: (1 not defined because of singularities)
##                                       Estimate Std. Error z value             Pr(>|z|)    
## (Intercept)                          -0.913653   0.200168  -4.564    0.000005008355996 ***
## tenure                               -0.033217   0.002395 -13.869 < 0.0000000000000002 ***
## ContractOne year                     -0.721312   0.117545  -6.136    0.000000000843715 ***
## ContractTwo year                     -1.405970   0.195686  -7.185    0.000000000000673 ***
## MonthlyCharges                        0.009941   0.003571   2.784              0.00538 ** 
## InternetServiceFiber optic            0.695906   0.151695   4.588    0.000004484858789 ***
## InternetServiceNo                    -0.791116   0.172999  -4.573    0.000004809104584 ***
## TechSupportNo internet service              NA         NA      NA                   NA    
## TechSupportYes                       -0.392848   0.097971  -4.010    0.000060760986340 ***
## PaymentMethodCredit card (automatic) -0.083920   0.126699  -0.662              0.50774    
## PaymentMethodElectronic check         0.405708   0.103025   3.938    0.000082181989324 ***
## PaymentMethodMailed check             0.021894   0.124701   0.176              0.86063    
## SeniorCitizen1                        0.380325   0.092392   4.116    0.000038481599441 ***
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## (Dispersion parameter for binomial family taken to be 1)
## 
##     Null deviance: 6517.2  on 5626  degrees of freedom
## Residual deviance: 4768.9  on 5615  degrees of freedom
## AIC: 4792.9
## 
## Number of Fisher Scoring iterations: 6
```

```r
# Generate predictions on the test set
predicted_probs <- predict(logit_model, test_data, type = "response")

# Convert probabilities to class labels using a 0.5 threshold
predicted_classes <- factor(ifelse(predicted_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# Evaluate the model using a Confusion Matrix
conf_matrix <- confusionMatrix(predicted_classes, test_data$Churn, positive = "Yes")
print(conf_matrix)
```

```text
## Confusion Matrix and Statistics
## 
##           Reference
## Prediction  No Yes
##        No  928 190
##        Yes 104 183
##                                           
##                Accuracy : 0.7907          
##                  95% CI : (0.7685, 0.8117)
##     No Information Rate : 0.7345          
##     P-Value [Acc > NIR] : 0.0000005945    
##                                           
##                   Kappa : 0.4208          
##                                           
##  Mcnemar's Test P-Value : 0.0000007148    
##                                           
##             Sensitivity : 0.4906          
##             Specificity : 0.8992          
##          Pos Pred Value : 0.6376          
##          Neg Pred Value : 0.8301          
##              Prevalence : 0.2655          
##          Detection Rate : 0.1302          
##    Detection Prevalence : 0.2043          
##       Balanced Accuracy : 0.6949          
##                                           
##        'Positive' Class : Yes             
## 
```

```r
#Trying the second approach for the customer Churn analysis.

# ==============================================================================
# SETUP & DATA PREPARATION
# ==============================================================================
# Load necessary libraries
library(readxl)
library(tidyverse)
library(gridExtra) # For arranging multiple plots side-by-side

# Import the data
df <- read_excel("C:/Users/Bharath.Haranath/Downloads/Telco-Customer-Churn.xlsx")

# Clean the data (as established in previous steps)
df_clean <- df %>%
  mutate(TotalCharges = as.numeric(TotalCharges),
         SeniorCitizen = as.factor(SeniorCitizen)) %>%
  mutate_if(is.character, as.factor) %>%
  select(-customerID) %>% # Remove the irrelevant ID column
  drop_na(TotalCharges)   # Drop the 11 rows with missing charges

# Create a custom theme for cleaner charts
my_theme <- theme_minimal() + 
  theme(plot.title = element_text(size = 11, face = "bold"),
        legend.position = "bottom")

# ==============================================================================
# PART 1: DEMOGRAPHICS (Who are they?)
# ==============================================================================
print("--- Analyzing Demographics ---")
```

```text
## [1] "--- Analyzing Demographics ---"
```

```r
# 1. Senior Citizen Status
p1 <- ggplot(df_clean, aes(x = SeniorCitizen, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Senior Citizen Status", y = "% of Customers", x = "Senior Citizen (0=No, 1=Yes)") +
  my_theme

# 2. Partner Status
p2 <- ggplot(df_clean, aes(x = Partner, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Partner Status", y = "", x = "Has Partner") +
  my_theme

# Display Demographic plots together
grid.arrange(p1, p2, ncol = 2)
```

![Churn by Partner Status](../figures/11_churn_by_partner_status.png)

```r
# ==============================================================================
# PART 2: SERVICES SUBSCRIBED (What are they experiencing?)
# ==============================================================================
print("--- Analyzing Services Subscribed ---")
```

```text
## [1] "--- Analyzing Services Subscribed ---"
```

```r
# 1. Internet Service Type
p3 <- ggplot(df_clean, aes(x = InternetService, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Internet Service", y = "% of Customers", x = "Service Type") +
  my_theme

# 2. Tech Support (Crucial add-on)
p4 <- ggplot(df_clean, aes(x = TechSupport, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Tech Support", y = "", x = "Has Tech Support") +
  my_theme

# Display Service plots together
grid.arrange(p3, p4, ncol = 2)
```

![Churn by Tech Support](../figures/12_churn_by_tech_support.png)

```r
# ==============================================================================
# PART 3: ACCOUNT & BILLING (How much financial friction is there?)
# ==============================================================================
print("--- Analyzing Account & Billing ---")
```

```text
## [1] "--- Analyzing Account & Billing ---"
```

```r
# 1. Contract Type
p5 <- ggplot(df_clean, aes(x = Contract, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Contract Type", y = "% of Customers", x = "Contract Length") +
  my_theme

# 2. Payment Method
p6 <- ggplot(df_clean, aes(x = PaymentMethod, fill = Churn)) + 
  geom_bar(position = "fill", color = "black") + 
  scale_y_continuous(labels = scales::percent) +
  labs(title = "Churn by Payment Method", y = "", x = "Method") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position = "none")

# Display Billing plots together
grid.arrange(p5, p6, ncol = 2)
```

![Churn by Payment Method](../figures/13_churn_by_payment_method.png)

```r
# 3. Continuous Variables: Tenure vs Monthly Charges
ggplot(df_clean, aes(x = tenure, y = MonthlyCharges, color = Churn)) + 
  geom_point(alpha = 0.3) + 
  geom_smooth(method = "lm", se = FALSE) +
  labs(title = "The Lifecycle: Tenure vs Monthly Charges", 
       x = "Tenure (Months)", y = "Monthly Charges ($)") +
  my_theme
```

```text
## `geom_smooth()` using formula = 'y ~ x'
```

![The Lifecycle: Tenure vs Monthly Charges](../figures/14_the_lifecycle_tenure_vs_monthly_charges.png)

```r
# ==============================================================================
# PART 4: LOGISTIC REGRESSION (Which category matters most?)
# ==============================================================================
print("--- Modeling the Drivers of Churn ---")
```

```text
## [1] "--- Modeling the Drivers of Churn ---"
```

```r
# We build a model using one representative variable from each of our three categories
# Demographics: SeniorCitizen, Partner
# Services: InternetService, TechSupport
# Billing: Contract, MonthlyCharges, tenure

churn_model <- glm(Churn ~ SeniorCitizen + Partner + 
                     InternetService + TechSupport + 
                     Contract + MonthlyCharges + tenure, 
                   data = df_clean, 
                   family = "binomial")

# View the summary to see the p-values and coefficients
# Look for the variables with the most stars (***) - these are your strongest drivers!
summary(churn_model)
```

```text
## 
## Call:
## glm(formula = Churn ~ SeniorCitizen + Partner + InternetService + 
##     TechSupport + Contract + MonthlyCharges + tenure, family = "binomial", 
##     data = df_clean)
## 
## Coefficients: (1 not defined because of singularities)
##                                 Estimate Std. Error z value             Pr(>|z|)    
## (Intercept)                    -0.679059   0.159163  -4.266   0.0000198620551243 ***
## SeniorCitizen1                  0.360012   0.081412   4.422   0.0000097745065416 ***
## PartnerYes                     -0.059833   0.069096  -0.866              0.38652    
## InternetServiceFiber optic      0.763180   0.134648   5.668   0.0000000144509402 ***
## InternetServiceNo              -0.867634   0.150539  -5.764   0.0000000082378269 ***
## TechSupportNo internet service        NA         NA      NA                   NA    
## TechSupportYes                 -0.433828   0.086911  -4.992   0.0000005987106780 ***
## ContractOne year               -0.778434   0.104101  -7.478   0.0000000000000756 ***
## ContractTwo year               -1.514260   0.172239  -8.792 < 0.0000000000000002 ***
## MonthlyCharges                  0.009542   0.003166   3.014              0.00258 ** 
## tenure                         -0.033036   0.002149 -15.373 < 0.0000000000000002 ***
## ---
## Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
## 
## (Dispersion parameter for binomial family taken to be 1)
## 
##     Null deviance: 8143.4  on 7031  degrees of freedom
## Residual deviance: 6012.9  on 7022  degrees of freedom
## AIC: 6032.9
## 
## Number of Fisher Scoring iterations: 6
```

```r
# Load pROC for evaluating model performance
library(pROC)
library(caret)

print("--- Evaluating Model Performance ---")
```

```text
## [1] "--- Evaluating Model Performance ---"
```

```r
# 1. Split data into Training (80%) and Testing (20%) sets
set.seed(123) # For reproducibility
trainIndex <- createDataPartition(df_clean$Churn, p = .8, list = FALSE)
train_data <- df_clean[trainIndex, ]
test_data <- df_clean[-trainIndex, ]

# 2. Retrain the exact model on just the training data
final_model <- glm(Churn ~ SeniorCitizen + Partner + InternetService + 
                     TechSupport + Contract + MonthlyCharges + tenure, 
                   data = train_data, family = "binomial")

# 3. Predict on the unseen Test Data
predicted_probs <- predict(final_model, test_data, type = "response")
# Convert probabilities > 50% to "Yes"
predicted_classes <- factor(ifelse(predicted_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# 4. Confusion Matrix (Accuracy, Sensitivity, Specificity)
conf_matrix <- confusionMatrix(predicted_classes, test_data$Churn, positive = "Yes")
print(conf_matrix)
```

```text
## Confusion Matrix and Statistics
## 
##           Reference
## Prediction  No Yes
##        No  930 190
##        Yes 102 183
##                                         
##                Accuracy : 0.7922        
##                  95% CI : (0.77, 0.8131)
##     No Information Rate : 0.7345        
##     P-Value [Acc > NIR] : 0.0000003100  
##                                         
##                   Kappa : 0.4237        
##                                         
##  Mcnemar's Test P-Value : 0.0000003556  
##                                         
##             Sensitivity : 0.4906        
##             Specificity : 0.9012        
##          Pos Pred Value : 0.6421        
##          Neg Pred Value : 0.8304        
##              Prevalence : 0.2655        
##          Detection Rate : 0.1302        
##    Detection Prevalence : 0.2028        
##       Balanced Accuracy : 0.6959        
##                                         
##        'Positive' Class : Yes           
## 
```

```r
# 5. Plot ROC Curve and calculate AUC
roc_curve <- roc(test_data$Churn, predicted_probs)
```

```text
## Setting levels: control = No, case = Yes
```

```text
## Setting direction: controls < cases
```

```r
plot(roc_curve, col = "blue", main = paste("ROC Curve (AUC =", round(auc(roc_curve), 3), ")"))
```

![Figure 15](../figures/15_figure_15.png)

```r
# ==============================================================================
# PART 5: RANDOM FOREST MODEL (Validating the Findings)
# ==============================================================================
print("--- Building the Random Forest Model ---")
```

```text
## [1] "--- Building the Random Forest Model ---"
```

```r
# Install the package if you do not have it: install.packages("randomForest")
library(randomForest)
```

```text
## Warning: package 'randomForest' was built under R version 4.6.1
```

```text
## randomForest 4.7-1.2
```

```text
## Type rfNews() to see new features/changes/bug fixes.
```

```text
## 
## Attaching package: 'randomForest'
```

```text
## The following object is masked from 'package:gridExtra':
## 
##     combine
```

```text
## The following object is masked from 'package:ggplot2':
## 
##     margin
```

```text
## The following object is masked from 'package:dplyr':
## 
##     combine
```

```r
library(caret)

# Ensure the target variable is a factor (required for classification in Random Forest)
train_data$Churn <- as.factor(train_data$Churn)
test_data$Churn <- as.factor(test_data$Churn)

# 1. Train the Random Forest Model
# We use all predictors (.) to let the algorithm find the most important ones naturally
set.seed(42)
rf_model <- randomForest(Churn ~ ., 
                         data = train_data, 
                         ntree = 500,        # Number of trees to grow
                         importance = TRUE)  # Calculate variable importance

# 2. View the model summary and Out-of-Bag (OOB) error rate
print(rf_model)
```

```text
## 
## Call:
##  randomForest(formula = Churn ~ ., data = train_data, ntree = 500,      importance = TRUE) 
##                Type of random forest: classification
##                      Number of trees: 500
## No. of variables tried at each split: 4
## 
##         OOB estimate of  error rate: 20.14%
## Confusion matrix:
##       No Yes class.error
## No  3727 404  0.09779714
## Yes  729 767  0.48729947
```

```r
# 3. Predict on unseen test data
rf_predictions <- predict(rf_model, test_data)

# 4. Evaluate Performance via Confusion Matrix
rf_conf_matrix <- confusionMatrix(rf_predictions, test_data$Churn, positive = "Yes")
print("--- Random Forest Confusion Matrix ---")
```

```text
## [1] "--- Random Forest Confusion Matrix ---"
```

```r
print(rf_conf_matrix)
```

```text
## Confusion Matrix and Statistics
## 
##           Reference
## Prediction  No Yes
##        No  933 180
##        Yes  99 193
##                                          
##                Accuracy : 0.8014         
##                  95% CI : (0.7796, 0.822)
##     No Information Rate : 0.7345         
##     P-Value [Acc > NIR] : 0.000000002974 
##                                          
##                   Kappa : 0.4529         
##                                          
##  Mcnemar's Test P-Value : 0.000001672185 
##                                          
##             Sensitivity : 0.5174         
##             Specificity : 0.9041         
##          Pos Pred Value : 0.6610         
##          Neg Pred Value : 0.8383         
##              Prevalence : 0.2655         
##          Detection Rate : 0.1374         
##    Detection Prevalence : 0.2078         
##       Balanced Accuracy : 0.7107         
##                                          
##        'Positive' Class : Yes            
## 
```

```r
# ==============================================================================
# PART 6: VARIABLE IMPORTANCE (The Business Insights)
# ==============================================================================
print("--- Extracting Feature Importance ---")
```

```text
## [1] "--- Extracting Feature Importance ---"
```

```r
# Extract the importance metrics
importance_data <- as.data.frame(importance(rf_model))
importance_data$Feature <- rownames(importance_data)

# Sort by MeanDecreaseAccuracy (how much accuracy the model loses if this feature is removed)
importance_data <- importance_data[order(-importance_data$MeanDecreaseAccuracy),]

# View the top 10 most important features
print(head(importance_data, 10))
```

```text
##                         No      Yes MeanDecreaseAccuracy MeanDecreaseGini          Feature
## tenure           26.707926 27.62546             46.06068        320.87364           tenure
## TotalCharges     28.199809 19.12896             44.06070        343.66060     TotalCharges
## Contract         -6.406197 33.29771             34.82342        165.87980         Contract
## MonthlyCharges   21.502928 16.81353             31.42296        313.97104   MonthlyCharges
## InternetService  15.941387 20.97239             24.40290         73.12484  InternetService
## TechSupport       7.551997 28.70975             20.63575         78.05986      TechSupport
## OnlineSecurity    7.560845 27.85509             18.44342         94.81242   OnlineSecurity
## OnlineBackup      8.908657 12.82462             14.80556         52.72572     OnlineBackup
## PaperlessBilling  0.783239 19.91328             14.53693         45.97938 PaperlessBilling
## PaymentMethod     3.041612 15.97356             14.07949        118.01707    PaymentMethod
```

```r
# Plot Variable Importance using ggplot2 for the final report
library(ggplot2)

ggplot(importance_data, aes(x = reorder(Feature, MeanDecreaseAccuracy), y = MeanDecreaseAccuracy)) +
  geom_col(fill = "steelblue", color = "black") +
  coord_flip() + # Flip coordinates for readability
  theme_minimal() +
  labs(title = "Random Forest: Variable Importance for Predicting Churn",
       subtitle = "Higher values indicate a stronger impact on customer churn",
       x = "Dataset Variables",
       y = "Importance (Mean Decrease in Accuracy)") +
  theme(plot.title = element_text(face = "bold"))
```

![Higher values indicate a stronger impact on customer churn](../figures/16_higher_values_indicate_a_stronger_impact_on_customer_churn.png)

```r
# ==============================================================================
# PART 7: MODEL PERFORMANCE COMPARISON (Logistic Regression vs. Random Forest)
# ==============================================================================
library(caret)
library(pROC)
library(ggplot2)
library(tidyverse)

# 1. Generate Class Predictions and Probabilities for Both Models
# --- Logistic Regression ---
lr_probs  <- predict(logit_model, test_data, type = "response")
lr_preds  <- factor(ifelse(lr_probs > 0.5, "Yes", "No"), levels = c("No", "Yes"))

# --- Random Forest ---
rf_preds  <- predict(rf_model, test_data, type = "response")
rf_probs  <- predict(rf_model, test_data, type = "prob")[, "Yes"]

# 2. Compute Confusion Matrices
cm_lr <- confusionMatrix(lr_preds, test_data$Churn, positive = "Yes")
cm_rf <- confusionMatrix(rf_preds, test_data$Churn, positive = "Yes")

# 3. Compute ROC and AUC Scores
roc_lr <- roc(test_data$Churn, lr_probs, levels = c("No", "Yes"))
```

```text
## Setting direction: controls < cases
```

```r
roc_rf <- roc(test_data$Churn, rf_probs, levels = c("No", "Yes"))
```

```text
## Setting direction: controls < cases
```

```r
auc_lr <- round(auc(roc_lr), 4)
auc_rf <- round(auc(roc_rf), 4)

# 4. Compile Performance Metrics Summary Table
model_comparison <- data.frame(
  Metric = c("Accuracy", "Sensitivity (Recall)", "Specificity", 
             "Precision (Pos Pred Value)", "F1-Score", "ROC-AUC"),
  
  Logistic_Regression = c(
    round(cm_lr$overall["Accuracy"], 4),
    round(cm_lr$byClass["Sensitivity"], 4),
    round(cm_lr$byClass["Specificity"], 4),
    round(cm_lr$byClass["Pos Pred Value"], 4),
    round(2 * (cm_lr$byClass["Pos Pred Value"] * cm_lr$byClass["Sensitivity"]) / 
            (cm_lr$byClass["Pos Pred Value"] + cm_lr$byClass["Sensitivity"]), 4),
    auc_lr
  ),
  
  Random_Forest = c(
    round(cm_rf$overall["Accuracy"], 4),
    round(cm_rf$byClass["Sensitivity"], 4),
    round(cm_rf$byClass["Specificity"], 4),
    round(cm_rf$byClass["Pos Pred Value"], 4),
    round(2 * (cm_rf$byClass["Pos Pred Value"] * cm_rf$byClass["Sensitivity"]) / 
            (cm_rf$byClass["Pos Pred Value"] + cm_rf$byClass["Sensitivity"]), 4),
    auc_rf
  )
)

print("--- PERFORMANCE COMPARISON TABLE ---")
```

```text
## [1] "--- PERFORMANCE COMPARISON TABLE ---"
```

```r
print(model_comparison)
```

```text
##                       Metric Logistic_Regression Random_Forest
## 1                   Accuracy              0.8000        0.8014
## 2       Sensitivity (Recall)              0.5255        0.5174
## 3                Specificity              0.8992        0.9041
## 4 Precision (Pos Pred Value)              0.6533        0.6610
## 5                   F1-Score              0.5825        0.5805
## 6                    ROC-AUC              0.8404        0.8272
```

```r
# ==============================================================================
# VISUALIZATION 1: OVERLAID ROC CURVES
# ==============================================================================
# Convert ROC objects to data frames for ggplot
df_roc_lr <- data.frame(
  Specificity = roc_lr$specificities,
  Sensitivity = roc_lr$sensitivities,
  Model = paste0("Logistic Regression (AUC = ", auc_lr, ")")
)

df_roc_rf <- data.frame(
  Specificity = roc_rf$specificities,
  Sensitivity = roc_rf$sensitivities,
  Model = paste0("Random Forest (AUC = ", auc_rf, ")")
)

df_roc_combined <- rbind(df_roc_lr, df_roc_rf)

ggplot(df_roc_combined, aes(x = 1 - Specificity, y = Sensitivity, color = Model)) +
  geom_line(size = 1.2) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey50") +
  scale_color_manual(values = c("darkblue", "darkgreen")) +
  theme_minimal() +
  labs(
    title = "ROC Curve Comparison: Logistic Regression vs. Random Forest",
    subtitle = "Evaluating Discriminatory Power on Unseen Test Data",
    x = "1 - Specificity (False Positive Rate)",
    y = "Sensitivity (True Positive Rate)",
    color = "Model"
  ) +
  theme(
    legend.position = "bottom",
    plot.title = element_text(face = "bold", size = 12)
  )
```

![Evaluating Discriminatory Power on Unseen Test Data](../figures/17_evaluating_discriminatory_power_on_unseen_test_data.png)

```r
# ==============================================================================
# VISUALIZATION 2: METRIC COMPARISON BAR CHART
# ==============================================================================
df_metrics_long <- model_comparison %>%
  pivot_longer(cols = c("Logistic_Regression", "Random_Forest"), 
               names_to = "Model", values_to = "Value")

ggplot(df_metrics_long, aes(x = Metric, y = Value, fill = Model)) +
  geom_bar(stat = "identity", position = "dodge", color = "black", width = 0.7) +
  geom_text(aes(label = round(Value, 3)), position = position_dodge(0.7), vjust = -0.5, size = 3) +
  scale_y_continuous(limits = c(0, 1.05), labels = scales::percent) +
  scale_fill_manual(values = c("steelblue", "forestgreen")) +
  theme_minimal() +
  labs(
    title = "Model Performance Metrics Comparison",
    x = "Evaluation Metric",
    y = "Score"
  ) +
  theme(
    axis.text.x = element_text(angle = 20, hjust = 1),
    plot.title = element_text(face = "bold")
  )
```

![Model Performance Metrics Comparison](../figures/18_model_performance_metrics_comparison.png)
