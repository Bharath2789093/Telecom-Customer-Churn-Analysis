# Dataset

`raw/Telco-Customer-Churn.xlsx` is the supplied Excel dataset, copied without alteration from `Telco-Customer-Churn(2).xlsx`. It is included so the folder contains the project inputs. An exact original source URL and redistribution licence were not supplied or verified; this package does not grant dataset rights.
