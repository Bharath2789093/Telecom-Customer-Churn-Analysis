# Upload to GitHub

1. Extract the ZIP file.
2. Create a GitHub repository named `telecom-customer-churn-analysis`.
3. Upload the contents inside the extracted project folder, preserving its subfolders. `README.md` must be at the repository root.
4. Include `.gitignore`. The dataset is included in this package; confirm its redistribution terms before making the repository public.
5. Commit with the message `Add telecom churn project with dataset, code, results and figures`.

Suggested description: “Academic customer churn analysis using R, logistic regression and random forest, with data, figures and recorded results.”

Suggested topics: `r`, `customer-churn`, `business-analytics`, `logistic-regression`, `random-forest`, `data-visualization`.

The source HTML can be downloaded and opened in a browser. The Markdown analysis and figure gallery are designed to display directly in GitHub. No GitHub account actions have been performed.
