# Future execution outputs

The portable R script writes its cleaned CSV here when run. Existing recorded results and figures are supplied in `../results/` and `../figures/`.
